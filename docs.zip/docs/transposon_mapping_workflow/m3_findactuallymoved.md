# step 3 of [[m0_overall_mapping_workflow|overall mapping workflow]]
!!! info "previous step:"
    [[m2_jupyterparty]]

- this step is used to determine the TEs that actually moved, versus ones that have the same position when comparing alignment coordinates

---
aliases: [step 8]
---
# Step 8 of [[a0_overall_anno_workflow|overall annotation workflow]]
!!! info "previous step:"
    [[a7_size_filter]]

### In & out
<table cellpadding="5" style="border: 1px solid black">
    <tr style="border: 1px solid black">
        <td style="border: 1px solid black" >INPUT</td>
        <td style="border: 1px solid black">size filtered gff3's</td>
    </tr>
    <tr>
        <td style="border: 1px solid black">OUTPUT</td>
        <td style="border: 1px solid black">a bunch of fun graphs</td>
    </tr>
</table>

graphing functions in jupyter notebook format:

![[TEUlt_reasonaTE_graphs.ipynb]]


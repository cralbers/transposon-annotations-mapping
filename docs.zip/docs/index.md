# Transposon Annotations and Mapping Process

This website is just my notes and process for generating transposon annotations and then tracking their movement during SPUR 2022 (Summer 2022). There are 2 main parts:

1. [[a0_overall_anno_workflow|overall annotation workflow]]
2. [[m0_overall_mapping_workflow|overall mapping workflow]]

Each of these pages have subpages that outline the general steps I took for each portion of this process! Hopefully this makes sense to somebody other than me :) 



